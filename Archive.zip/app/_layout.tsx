import AppText from "@/components/ui/apptext";
import SplashView from "@/components/ui/splashview";
import { colors } from "@/constants/colors";
import { images } from "@/constants/images";
import { userStore } from "@/stores/userstore";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useFonts } from "expo-font";
import { Image } from "expo-image";
import { Stack } from "expo-router";
import * as SplashScreen from "expo-splash-screen";
import { StatusBar } from "expo-status-bar";
import React from "react";
import { Platform, StyleSheet, View } from "react-native";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { ToastProvider } from "react-native-toast-notifications";
import { ToastProps } from "react-native-toast-notifications/lib/typescript/toast";
import { useStore } from "zustand";

SplashScreen.preventAutoHideAsync();

const SPLASH_MIN_MS = 2000;
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // No retry/backoff config existed here before, so every failed
      // query (this hook and every other one in the app) inherited React
      // Query's default of retrying 3x with backoff - including on 4xx
      // client errors like 403/404/429 that will never succeed by
      // retrying. For 429 specifically (seen on the weather endpoint)
      // this actively makes things worse: the retries themselves keep
      // the endpoint rate-limited, so it can never recover on its own.
      // Only retry transient/server errors (network issues, 5xx), and
      // only once.
      retry: (failureCount, error: any) => {
        const status = error?.status;
        if (status && status >= 400 && status < 500) return false;
        return failureCount < 1;
      },
    },
  },
});

export default function RootLayout() {
  SplashScreen.setOptions({
    fade: true,
    duration: 400,
  });

  const user = useStore(userStore, (state) => state.user);
  const hasHydrated = useStore(userStore, (state) => state.hasHydrated);
  const [appReady, setAppReady] = React.useState(false);
  const [loaded] = useFonts({
    Regular: require("../assets/fonts/Inter-Regular.ttf"),
    Medium: require("../assets/fonts/Inter-Medium.ttf"),
    SemiBold: require("../assets/fonts/Inter-SemiBold.ttf"),
    Bold: require("../assets/fonts/Inter-Bold.ttf"),
  });

  React.useEffect(() => {
    // Wait for fonts AND the persisted session to finish loading back out
    // of MMKV before deciding whether to show the login screen or the
    // main app below - otherwise a logged-in person briefly reads as
    // `user: null` on every cold start/reload and gets bounced to login
    // even though their session was saved just fine.
    if (!loaded || !hasHydrated) return;

    const timer = setTimeout(async () => {
      await SplashScreen.hideAsync();
      setAppReady(true);
    }, SPLASH_MIN_MS);

    return () => clearTimeout(timer);
  }, [loaded, hasHydrated]);

  if (!appReady) {
    return <SplashView />;
  }

  const renderToastType = {
    custom_type: (toast: ToastProps) => (
      <View style={styles.toastContainer}>
        <Image source={images.logo} style={styles.toastImage} />
        <AppText fontSize={16} color="black" fontFamily="Regular">
          {toast.message}
        </AppText>
      </View>
    ),
  };

  return (
    <SafeAreaProvider>
      <QueryClientProvider client={queryClient}>
        <StatusBar style="dark" />
        <ToastProvider offset={70} renderType={renderToastType}>
          {!user ? (
            <Stack screenOptions={{ headerShown: false }}>
              <Stack.Screen name="(auth)" />
            </Stack>
          ) : (
            <Stack screenOptions={{ headerShown: false }}>
              <Stack.Screen name="(tabs)" />
              <Stack.Screen name="more" />
              <Stack.Screen name="home" />
              <Stack.Screen name="myfarm" />
              <Stack.Screen name="myfarmers" />
              <Stack.Screen name="credits" />
              <Stack.Screen
                name="notifications"
                options={{
                  presentation: "modal",
                  animation: Platform.OS === "android" ? "none" : "default",
                }}
              />
            </Stack>
          )}
        </ToastProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  toastContainer: {
    paddingHorizontal: 15,
    paddingVertical: 13,
    backgroundColor: colors.white,
    borderRadius: 2000,
    flexDirection: "row",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
    elevation: 2,
    alignItems: "center",
    marginHorizontal: 30,
    marginBottom: 10,
  },
  toastImage: { width: 24, height: 24, marginRight: 10, borderRadius: 2000 },
});